# POTLS-DB Configuration Files
## Palm Oil Technical Lignin Structural Dataset — LGS Input Parameters

### Structure
```
POTLS_LGS_configs/
├── central/           # 9 files — central parameter estimates
├── sensitivity_low/   # 9 files — lower bound linkage fractions
├── sensitivity_high/  # 9 files — upper bound linkage fractions
└── README_POTLS_DB.md
```
Total: 27 configuration files → 27 LGS runs

### Archetype classification
| Archetype        | Configurations              | Rationale                          |
|------------------|-----------------------------|-------------------------------------|
| SG-rico          | EFB Kraft, EFB Soda         | S/G ≥ 1.5 → hardwood-like          |
| SG-intermedio    | EFB Org, MF Kraft           | S/G 0.4–0.7 → grass/hardwood mix   |
| G-dominante      | MF Soda/Org, KS all three   | S/G ≤ 0.2 → near-softwood          |

### Parameter sources
- S/G ratios: HSQC-NMR experimental (Oñate-Gutiérrez et al. 2025)
- Bond proportions: Eswaran et al. 2022 (Sci. Data) — hardwood/softwood ranges
- DP_min: Mw estimated from MALDI-TOF / M0_weighted
- DP_max: Mw_P75 from GPC literature / M0_weighted
  Sources: Mohamad Ibrahim 2004, Hussin 2013/2014, Constant 2016 (Green Chem.)

### Analytical verification
van Krevelen predicted centroids (H/C, O/C):
  EFB Kraft: (1.096, 0.356) | EFB Soda: (1.098, 0.353) | EFB Org: (1.105, 0.343)
  MF Kraft:  (1.102, 0.347) | MF Soda:  (1.111, 0.333) | MF Org:  (1.108, 0.337)
  KS Kraft:  (1.109, 0.337) | KS Soda:  (1.111, 0.333) | KS Org:  (1.109, 0.337)
All values within Figure 7a envelope of published paper (Oñate-Gutiérrez et al. 2025).

### Convergence criterion for number of structures per run
Generate structures per DP step until:
  ΔMEAN(MW) < 1% and ΔSD(MW) < 1% between consecutive batches of 500 structures.
Expected convergence: 2000–5000 structures per configuration × 3 variants = 6000–15000/config.
Total dataset target: ~54,000–135,000 structures (POTLS-DB v1.0).
